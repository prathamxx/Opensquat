# Opensquat

A Pen created on CodePen.io. Original URL: [https://codepen.io/prathxm_x/pen/YzBGyzX](https://codepen.io/prathxm_x/pen/YzBGyzX).

